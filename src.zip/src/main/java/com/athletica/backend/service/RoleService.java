package com.athletica.backend.service;

import java.util.List;

import com.athletica.backend.model.Role;

public interface RoleService {
  List<Role> getAllRoles();
}
