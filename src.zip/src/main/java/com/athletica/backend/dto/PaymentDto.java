package com.athletica.backend.dto;

public class PaymentDto {
  
}
