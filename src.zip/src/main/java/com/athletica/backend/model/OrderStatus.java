package com.athletica.backend.model;

public enum OrderStatus {
  CREATED, PAID, PROCESSING, SHIPPED, DELIVERED, CANCELLED, REFUNDED
}
