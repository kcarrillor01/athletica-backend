package com.athletica.backend.model;

public enum PaymentMethod {
  CARD, CASH, TRANSFER, SIMULATED
}

