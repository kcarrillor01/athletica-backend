package com.athletica.backend.model;

public enum ShipmentStatus {
  PENDING, IN_TRANSIT, DELIVERED, RETURNED
}
