package com.athletica.backend.model;

public enum PaymentStatus {
  PENDING, COMPLETED, FAILED, REFUNDED
}
